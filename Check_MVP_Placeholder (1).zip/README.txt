Welkom bij de MVP van Check!

Wat je nu kunt doen:
1. Ga naar https://vercel.com/import
2. Upload deze zip of koppel een GitHub repo
3. Volg de stappen: kies framework 'Next.js', root directory '/'
4. Voeg daarna je domein toe (thecheck.nl)
5. Vercel geeft je dan automatisch de TXT-verificatiecode voor je DNS

Veel succes!
